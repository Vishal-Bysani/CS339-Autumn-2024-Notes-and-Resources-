ready :: IO Bool
ready = getChar >>= 
